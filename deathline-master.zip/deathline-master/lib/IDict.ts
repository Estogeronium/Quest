export interface IDict<T> {
    [key: string]: T;
}